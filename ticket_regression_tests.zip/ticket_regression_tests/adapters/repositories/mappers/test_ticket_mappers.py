from __future__ import annotations

from datetime import datetime, timezone

from src.adapters.repositories.mappers.ticket_mapper import TicketMapper
from src.adapters.repositories.mappers.ticket_user_mapper import TicketUserMapper
from src.domain.statuses.ticket_status import TicketStatus
from src.domain.ticket_user import TicketUserStatus


BASE_TIME = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)


def test_ticket_status_mapper_preserves_none_optional_datetimes() -> None:
    record = TicketMapper.row_to_status_record(
        {
            "status_id": 1,
            "actor_employee_id": 100,
            "status": TicketStatus.CREATED.value,
            "date_created": BASE_TIME.isoformat(),
            "executor_id": None,
            "planned_start_at": None,
            "planned_finish_at": None,
            "actual_started_at": None,
            "actual_finished_at": None,
            "comment": "",
        }
    )

    assert record.planned_start_at is None
    assert record.planned_finish_at is None
    assert record.actual_started_at is None
    assert record.actual_finished_at is None


def test_ticket_mapper_serializes_zero_creator_admin_as_sql_null() -> None:
    from src.domain.ticket import Ticket

    ticket = Ticket.create_from_ticket_user(
        client_id=10,
        user_id=20,
        contact_user_id=0,
        user_ticket_id=30,
        text_of_ticket="Need help",
        date_created=BASE_TIME,
    )

    params = TicketMapper.ticket_params(ticket)

    assert params["admin_id"] is None


def test_ticket_user_status_mapper_reads_comment_into_status_comment() -> None:
    record = TicketUserMapper.row_to_status(
        {
            "status_id": 1,
            "actor_employee_id": 20,
            "status": TicketUserStatus.CREATED.value,
            "comment": "  created by user  ",
            "date_created": BASE_TIME.isoformat(),
        }
    )

    assert record.status_comment == "created by user"


def test_ticket_user_status_mapper_writes_status_comment_to_comment_column() -> None:
    from src.domain.ticket_user import StatusRecordTicketUser

    record = StatusRecordTicketUser(
        actor_employee_id=20,
        status=TicketUserStatus.CREATED,
        status_comment="phone request",
        date_created=BASE_TIME,
    )

    params = TicketUserMapper.status_record_params(
        ticket_id=30,
        record=record,
    )

    assert params["comment"] == "phone request"
