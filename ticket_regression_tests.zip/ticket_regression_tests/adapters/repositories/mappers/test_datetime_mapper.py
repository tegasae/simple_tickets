from __future__ import annotations

from datetime import datetime, timezone

import pytest

from src.adapters.repositories.mappers.auxiliary import dt_from_sqlite


def test_dt_from_sqlite_none_returns_none() -> None:
    assert dt_from_sqlite(None) is None


def test_dt_from_sqlite_empty_string_returns_none() -> None:
    assert dt_from_sqlite("   ") is None


def test_dt_from_sqlite_naive_datetime_becomes_utc() -> None:
    value = datetime(2024, 1, 1, 12, 0)

    result = dt_from_sqlite(value)

    assert result == datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)


def test_dt_from_sqlite_iso_string_is_normalized_to_utc() -> None:
    result = dt_from_sqlite("2024-01-01T15:00:00+03:00")

    assert result == datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)


def test_dt_from_sqlite_invalid_string_raises() -> None:
    with pytest.raises(ValueError):
        dt_from_sqlite("not-a-datetime")
